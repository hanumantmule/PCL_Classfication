import numpy as np
import pdb

from sklearn.datasets import make_classification
from sklearn.mixture import GaussianMixture as GMM
import open3d as o3d

def fisher_vector(xx, gmm):
    """Computes the Fisher vector on a set of descriptors.

    Parameters
    ----------
    xx: array_like, shape (N, D) or (D, )
        The set of descriptors

    gmm: instance of sklearn mixture.GMM object
        Gauassian mixture model of the descriptors.

    Returns
    -------
    fv: array_like, shape (K + 2 * D * K, )
        Fisher vector (derivatives with respect to the mixing weights, means
        and variances) of the given descriptors.

    Reference
    ---------
    J. Krapac, J. Verbeek, F. Jurie.  Modeling Spatial Layout with Fisher
    Vectors for Image Categorization.  In ICCV, 2011.
    http://hal.inria.fr/docs/00/61/94/03/PDF/final.r1.pdf

    """
    xx = np.atleast_2d(xx)
    N = xx.shape[0]

    # Compute posterior probabilities.
    Q = gmm.predict_proba(xx)  # NxK

    # Compute the sufficient statistics of descriptors.
    Q_sum = np.sum(Q, 0)[:, np.newaxis] / N
    Q_xx = np.dot(Q.T, xx) / N
    Q_xx_2 = np.dot(Q.T, xx ** 2) / N

    # Compute derivatives with respect to mixing weights, means and variances.
    d_pi = Q_sum.squeeze() - gmm.weights_
    d_mu = Q_xx - Q_sum * gmm.means_
    d_sigma = (
            - Q_xx_2
            - Q_sum * gmm.means_ ** 2
            + Q_sum * gmm.covariances_
            + 2 * Q_xx * gmm.means_)

    # Merge derivatives into a vector.
    return np.hstack((d_pi, d_mu.flatten(), d_sigma.flatten()))


def main():
    # Short demo.
    K = 32
    N = 1000

    xx, _ = make_classification(n_samples=N)
    pcd = o3d.io.read_point_cloud("C:\\bin\\PCLTest\\Dataset\\3d_haris_keypoints.pcd",format='xyz')
    import pandas as pd
    df=pd.read_csv('C:\\bin\\PCLTest\\Dataset\\decriptor.csv',header=None)

    out_arr = np.asarray(df)
    print ("output array from input list : ", out_arr)

    xx_tr, xx_te = out_arr[: -100], out_arr[-100: ]
    print(xx_tr.shape)
    print(xx_te.shape)

    gmm = GMM(n_components=K, covariance_type='diag')
    gmm.fit(xx_tr)

    fv = fisher_vector(xx_te, gmm)
    print(fv)
    print(fv.shape)
    # pdb.set_trace()


if __name__ == '__main__':
    main()