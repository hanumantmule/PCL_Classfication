import numpy as np
from feature_aggregation import BagOfWords, FisherVectors
import open3d as o3d

import pandas as pd
df=pd.read_csv('C:\\bin\\PCLTest\\Dataset\\decriptor.csv',header=None)

out_arr = np.asarray(df)
print(out_arr[np.isnan(out_arr)])

out_arr[np.isnan(out_arr)]=np.median(out_arr[~np.isnan(out_arr)])
X = np.random.rand(10, 6)
# print(X.shape)
# bow = BagOfWords(10)
fv = FisherVectors(5)

# bow.fit(X)
fv.fit(out_arr)

print(out_arr)

G2 = fv.transform(out_arr)

print(G2.shape)